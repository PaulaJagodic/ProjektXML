<!DOCTYPE html>
<html lang="hr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slavenska Mitologija</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        .navbar {
            background-color: #343a40 !important;
        }

        .navbar-brand {
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: #fff !important;
        }

        .zanimljive-cinjenice {
            list-style-type: none;
            padding: 0;
        }

        .zanimljive-cinjenice li {
            margin-bottom: 10px;
        }

        .naslov-cinjenice {
            font-weight: bold;
            color: #007bff;
        }

        .opis-cinjenice {
            color: #555;
        }
    </style>
</head>

<body>
    <?php include 'navbar.php'; ?>

    <section id="home" class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center">
                <h2>Zanimljive činjenice o slavenskoj mitologiji</h2>
                <ul class="zanimljive-cinjenice">
                    <li>
                        <span class="naslov-cinjenice">Višebogovlje:</span>
                        <span class="opis-cinjenice">Slavenska mitologija je politeistička, što znači da vjeruje
                            u postojanje više bogova. Ovi bogovi su često povezani s prirodnim pojavama, elementima,
                            ili ljudskim osobinama.</span>
                    </li>
                    <li>
                        <span class="naslov-cinjenice">Perun:</span>
                        <span class="opis-cinjenice">Jedan od najpoznatijih bogova slavenske mitologije je Perun,
                            bog groma, munje, i neba. On je često prikazivan s oružjem u ruci, kao što su koplje
                            ili sjekira.</span>
                    </li>
                    <li>
                        <span class="naslov-cinjenice">Veles:</span>
                        <span class="opis-cinjenice">Veles je bog podzemlja, stoke, trgovine, i umjetnosti. On je
                            često prikazivan kao vodenasti ili zmajoliki lik. Veles je imao složen odnos s Perunom,
                            koji je simbolizirao sukob.</span>
                    </li>
                </ul>
            </div>
        </div>
    </section>

    <section id="mitoloska_bica" class="container py-5">
    </section>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>

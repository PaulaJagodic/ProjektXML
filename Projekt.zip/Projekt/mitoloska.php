<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slavenska Mitologija - Mitološka bića</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>

    </style>
</head>

<body>
    <?php include 'navbar.php'; ?>

    <section id="mitoloska_bica" class="container py-5">
        <h2 class="text-center mb-4">Mitološka bića</h2>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Naziv bića</th>
                        <th>Država</th>
                        <th>Božanstvo</th>
                        <th>Opis</th>
                    </tr>
                </thead>
                <?php
                $xml = simplexml_load_file('bica.xml');
                foreach ($xml->bice as $bice) {
                    echo "<tr>";
                    echo "<td>{$bice->naziv}</td>";
                    echo "<td>{$bice->drzava}</td>";
                    echo "<td>{$bice->bozanstvo}</td>";
                    echo "<td>{$bice->opis}</td>";
                    echo "</tr>";
                }
                ?>
            </table>
        </div>
    </section>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>

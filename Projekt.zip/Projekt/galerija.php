<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slavenska Mitologija - Galerija</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        .navbar {
            background-color: #343a40 !important;
        }

        .navbar-brand {
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: #fff !important;
        }

        #home {
            background-color: #fff;
            padding: 60px 0;
        }

        #home h2 {
            color: #343a40;
        }

        .card {
            margin-bottom: 30px;
            height: 100%;
        }

        .card img {
            max-width: 100%;
            height: 100%;
            object-fit: cover;
        }
    </style>
</head>

<body>
    <?php include 'navbar.php'; ?>

    <section id="home" class="container py-5">
        <h2 class="text-center mb-4">Galerija</h2>
        <div class="row">
            <?php
            $imageFolder = 'slike/';
            $images = glob($imageFolder . '*.jpg');
            $counter = 0;
            foreach ($images as $image) :
            ?>
                <div class="col-md-4">
                    <div class="card">
                        <img src="<?php echo $image; ?>" class="card-img-top" alt="Slika">
                    </div>
                </div>
                <?php
                $counter++;
                if ($counter % 3 == 0) echo '</div><div class="row">';
                ?>
            <?php endforeach; ?>
        </div>
    </section>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
